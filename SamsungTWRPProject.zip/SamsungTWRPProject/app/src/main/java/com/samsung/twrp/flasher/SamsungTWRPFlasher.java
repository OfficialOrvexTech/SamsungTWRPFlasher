package com.samsung.twrp.flasher;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Downloads an official TWRP .img through its per-file HTML page and verifies
 * the published SHA-256 checksum. This class never flashes a device partition.
 */
public final class SamsungTWRPFlasher {
    private static final String BASE_URL = "https://dl.twrp.me/";
    private static final String USER_AGENT = "SamsungTWRPDownloader/1.0 (Android)";
    private static final int CONNECT_TIMEOUT_MS = 15000;
    private static final int READ_TIMEOUT_MS = 60000;
    private static final long MIN_IMAGE_BYTES = 512L * 1024L;

    private static final Pattern ANCHOR_PATTERN = Pattern.compile(
            "(?is)<a\\b([^>]*)>(.*?)</a>");
    private static final Pattern HREF_PATTERN = Pattern.compile(
            "(?is)\\bhref\\s*=\\s*([\\\"'])(.*?)\\1");
    private static final Pattern SHA_PATTERN = Pattern.compile("(?i)\\b([a-f0-9]{64})\\b");
    private static final Pattern VERSION_PATTERN = Pattern.compile(
            "(?i)twrp-([0-9]+(?:[._-][0-9]+)*)");

    public interface LogCallback {
        void onLog(String message);
    }

    private static final class Candidate {
        final String fileName;
        final String htmlPageUrl;

        Candidate(String fileName, String htmlPageUrl) {
            this.fileName = fileName;
            this.htmlPageUrl = htmlPageUrl;
        }
    }

    private SamsungTWRPFlasher() { }

    /**
     * Downloads the newest listed .img for the supplied codename.
     * Returns an absolute path, or a message beginning with "HATA:".
     */
    public static String downloadLatestImg(
            String deviceCode, File cacheDir, LogCallback log) {
        if (deviceCode == null || !deviceCode.trim().matches("[A-Za-z0-9_-]{1,64}")) {
            return "HATA: Cihaz kod adı geçersiz. Harf, rakam, alt çizgi ve tire kullanın.";
        }

        final String code = deviceCode.trim().toLowerCase(Locale.ROOT);
        final String directoryUrl = BASE_URL + code + "/";
        File partFile = null;

        try {
            log(log, "Resmî TWRP cihaz sayfası kontrol ediliyor: " + directoryUrl);
            String directoryHtml = fetchText(directoryUrl, BASE_URL);
            if (directoryHtml == null) {
                return "HATA: Bu cihaz kodu için TWRP dizini bulunamadı veya sunucu yanıt vermedi.";
            }

            List<Candidate> candidates = findImgCandidates(directoryHtml, directoryUrl, code);
            if (candidates.isEmpty()) {
                return "HATA: Cihaz dizininde indirilebilir .img HTML sayfası bulunamadı.";
            }

            Collections.sort(candidates, (left, right) ->
                    compareVersions(right.fileName, left.fileName));
            Candidate selected = candidates.get(0);
            log(log, "Seçilen resmî .img sayfası: " + selected.fileName);

            if (cacheDir == null) {
                return "HATA: Önbellek klasörü belirtilmedi.";
            }
            if (cacheDir.exists() && !cacheDir.isDirectory()) {
                return "HATA: Önbellek yolu klasör değil.";
            }
            if (!cacheDir.exists() && !cacheDir.mkdirs()) {
                return "HATA: Önbellek klasörü oluşturulamadı.";
            }

            log(log, "Dosyanın resmî HTML indirme sayfası açılıyor...");
            String filePageHtml = fetchText(selected.htmlPageUrl, directoryUrl);
            if (filePageHtml == null) {
                return "HATA: Dosyanın resmî HTML sayfası açılamadı.";
            }

            String downloadUrl = findDownloadUrl(filePageHtml, selected.htmlPageUrl,
                    code, selected.fileName);
            if (downloadUrl == null) {
                return "HATA: Resmî HTML sayfasında indirme bağlantısı bulunamadı.";
            }

            String shaUrl = findSha256Url(filePageHtml, selected.htmlPageUrl, code,
                    selected.fileName);
            if (shaUrl == null) {
                return "HATA: Resmî sayfada SHA-256 bağlantısı bulunamadı. Doğrulanmamış dosya indirilmeyecek.";
            }

            String expectedSha = fetchSha256(shaUrl, selected.htmlPageUrl);
            if (expectedSha == null) {
                return "HATA: Resmî SHA-256 değeri okunamadı.";
            }

            File finalFile = new File(cacheDir, selected.fileName);
            if (finalFile.isFile() && finalFile.length() >= MIN_IMAGE_BYTES) {
                if (verifySha256(finalFile, expectedSha)) {
                    log(log, "Önbellekteki dosya SHA-256 ile doğrulandı.");
                    log(log, "SHA-256: " + expectedSha);
                    return finalFile.getAbsolutePath();
                }
                log(log, "Önbellekteki dosya doğrulanamadı; silinip yeniden indirilecek.");
                if (!finalFile.delete()) {
                    return "HATA: Bozuk önbellek dosyası silinemedi.";
                }
            }

            partFile = new File(cacheDir, selected.fileName + ".part");
            if (partFile.exists() && !partFile.delete()) {
                return "HATA: Önceki yarım indirme dosyası silinemedi.";
            }

            log(log, "Resmî TWRP .img dosyası indiriliyor...");
            if (!downloadBinary(downloadUrl, selected.htmlPageUrl, partFile, log)) {
                return "HATA: İndirme eksik, geçersiz veya HTML yanıtı döndürdü.";
            }

            log(log, "SHA-256 bütünlük kontrolü yapılıyor...");
            if (!verifySha256(partFile, expectedSha)) {
                return "HATA: SHA-256 uyuşmadı. Dosya kullanılmamalı.";
            }

            if (finalFile.exists() && !finalFile.delete()) {
                return "HATA: Eski hedef dosya değiştirilemedi.";
            }
            if (!partFile.renameTo(finalFile)) {
                return "HATA: Doğrulanan dosya önbelleğe taşınamadı.";
            }
            partFile = null;

            log(log, "İndirme tamamlandı ve SHA-256 doğrulandı.");
            log(log, "Dosya: " + finalFile.getAbsolutePath());
            log(log, "SHA-256: " + expectedSha);
            log(log, "Not: Bu uygulama dosyayı cihaza yazmaz.");
            return finalFile.getAbsolutePath();
        } catch (Exception e) {
            String detail = e.getMessage();
            return "HATA: " + (detail == null ? e.getClass().getSimpleName() : detail);
        } finally {
            if (partFile != null && partFile.exists()) {
                //noinspection ResultOfMethodCallIgnored
                partFile.delete();
            }
        }
    }

    private static List<Candidate> findImgCandidates(
            String html, String pageUrl, String deviceCode) {
        List<Candidate> result = new ArrayList<>();
        URI base = URI.create(pageUrl);
        Matcher anchorMatcher = ANCHOR_PATTERN.matcher(html);

        while (anchorMatcher.find()) {
            Matcher hrefMatcher = HREF_PATTERN.matcher(anchorMatcher.group(1));
            if (!hrefMatcher.find()) continue;

            String href = decodeHtml(hrefMatcher.group(2).trim());
            String visibleText = stripTags(decodeHtml(anchorMatcher.group(2))).trim();
            URI resolved = resolveTwrpUri(base, href, deviceCode);
            if (resolved == null || resolved.getPath() == null) continue;

            String pathName = lastPathPart(resolved.getPath());
            String visibleName = lastPathPart(visibleText);
            String fileName = isImgFileName(visibleName) ? visibleName : pathName;
            if (!isImgFileName(fileName)) {
                if (pathName.toLowerCase(Locale.ROOT).endsWith(".img.html")) {
                    fileName = pathName.substring(0, pathName.length() - ".html".length());
                } else {
                    continue;
                }
            }
            if (!isImgFileName(fileName)) continue;

            String lowerPathName = pathName.toLowerCase(Locale.ROOT);
            String filePage = resolved.toString();
            if (!lowerPathName.endsWith(".img.html")) {
                if (!lowerPathName.endsWith(".img")) continue;
                filePage += ".html";
            }

            boolean duplicate = false;
            for (Candidate old : result) {
                if (old.fileName.equals(fileName)) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) result.add(new Candidate(fileName, filePage));
        }
        return result;
    }

    private static boolean isImgFileName(String name) {
        if (name == null) return false;
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".img")
                && (lower.startsWith("twrp-") || lower.equals("recovery.img"));
    }

    private static String findDownloadUrl(
            String html, String pageUrl, String deviceCode, String expectedName) {
        for (String[] link : extractLinks(html)) {
            String text = stripTags(decodeHtml(link[1])).trim().toLowerCase(Locale.ROOT);
            URI resolved = resolveTwrpUri(URI.create(pageUrl), link[0], deviceCode);
            if (resolved == null || resolved.getPath() == null) continue;
            String pathName = lastPathPart(resolved.getPath());
            if (text.startsWith("download") && pathName.equals(expectedName)) {
                return resolved.toString();
            }
        }
        return null;
    }

    private static String findSha256Url(
            String html, String pageUrl, String deviceCode, String expectedName) {
        for (String[] link : extractLinks(html)) {
            String text = stripTags(decodeHtml(link[1])).toLowerCase(Locale.ROOT);
            URI resolved = resolveTwrpUri(URI.create(pageUrl), link[0], deviceCode);
            if (resolved == null || resolved.getPath() == null) continue;
            String path = resolved.getPath().toLowerCase(Locale.ROOT);
            if ((text.contains("sha256") || path.endsWith(".sha256"))
                    && path.endsWith(expectedName.toLowerCase(Locale.ROOT) + ".sha256")) {
                return resolved.toString();
            }
        }
        return null;
    }

    private static List<String[]> extractLinks(String html) {
        List<String[]> links = new ArrayList<>();
        Matcher anchorMatcher = ANCHOR_PATTERN.matcher(html);
        while (anchorMatcher.find()) {
            Matcher hrefMatcher = HREF_PATTERN.matcher(anchorMatcher.group(1));
            if (hrefMatcher.find()) {
                links.add(new String[]{decodeHtml(hrefMatcher.group(2).trim()), anchorMatcher.group(2)});
            }
        }
        return links;
    }

    private static URI resolveTwrpUri(URI base, String href, String deviceCode) {
        try {
            URI resolved = base.resolve(href);
            if (!isAllowedTwrpUri(resolved) || resolved.getPath() == null) return null;
            String prefix = "/" + deviceCode + "/";
            if (!resolved.getPath().startsWith(prefix)) return null;
            return resolved;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static boolean isAllowedTwrpUri(URI uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme())) return false;
        String host = uri.getHost();
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        return host.equals("dl.twrp.me") || host.endsWith(".dl.twrp.me");
    }

    private static String fetchSha256(String url, String referer) throws IOException {
        String body = fetchText(url, referer);
        if (body == null) return null;
        Matcher matcher = SHA_PATTERN.matcher(body);
        return matcher.find() ? matcher.group(1).toLowerCase(Locale.ROOT) : null;
    }

    private static String fetchText(String url, String referer) throws IOException {
        HttpURLConnection connection = openConnection(url, referer);
        try {
            int status = connection.getResponseCode();
            if (status != HttpURLConnection.HTTP_OK || !isAllowedFinalUrl(connection.getURL())) {
                return null;
            }
            StringBuilder text = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    connection.getInputStream(), StandardCharsets.UTF_8))) {
                char[] buffer = new char[4096];
                int count;
                while ((count = reader.read(buffer)) != -1) {
                    text.append(buffer, 0, count);
                    if (text.length() > 2_000_000) {
                        throw new IOException("Sunucu metin yanıtı beklenenden büyük.");
                    }
                }
            }
            return text.toString();
        } finally {
            connection.disconnect();
        }
    }

    private static boolean downloadBinary(
            String url, String referer, File target, LogCallback log) throws IOException {
        HttpURLConnection connection = openConnection(url, referer);
        try {
            int status = connection.getResponseCode();
            if (status != HttpURLConnection.HTTP_OK || !isAllowedFinalUrl(connection.getURL())) {
                return false;
            }
            String contentType = connection.getContentType();
            if (contentType != null && contentType.toLowerCase(Locale.ROOT).contains("text/html")) {
                return false;
            }

            long expectedLength = connection.getContentLengthLong();
            long received = 0;
            int nextPercent = 20;
            try (InputStream input = new BufferedInputStream(connection.getInputStream());
                 FileOutputStream output = new FileOutputStream(target)) {
                byte[] buffer = new byte[16 * 1024];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    output.write(buffer, 0, count);
                    received += count;
                    if (expectedLength > 0 && log != null) {
                        int percent = (int) (received * 100L / expectedLength);
                        while (percent >= nextPercent && nextPercent <= 100) {
                            log(log, "İndiriliyor: %" + nextPercent);
                            nextPercent += 20;
                        }
                    }
                }
                output.flush();
                output.getFD().sync();
            }
            return received >= MIN_IMAGE_BYTES && (expectedLength <= 0 || received == expectedLength);
        } finally {
            connection.disconnect();
        }
    }

    private static HttpURLConnection openConnection(String url, String referer) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("User-Agent", USER_AGENT);
        connection.setRequestProperty("Accept", "text/html, text/plain, application/octet-stream, */*;q=0.8");
        connection.setRequestProperty("Accept-Language", "en-US,en;q=0.8");
        if (referer != null) connection.setRequestProperty("Referer", referer);
        connection.setInstanceFollowRedirects(true);
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        return connection;
    }

    private static boolean isAllowedFinalUrl(URL url) {
        try {
            return isAllowedTwrpUri(url.toURI());
        } catch (Exception ignored) {
            return false;
        }
    }

    private static boolean verifySha256(File file, String expected) {
        if (file == null || !file.isFile() || expected == null
                || !expected.matches("(?i)[a-f0-9]{64}")) return false;
        try (InputStream input = new BufferedInputStream(new FileInputStream(file))) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[16 * 1024];
            int count;
            while ((count = input.read(buffer)) != -1) digest.update(buffer, 0, count);
            StringBuilder actual = new StringBuilder(64);
            for (byte value : digest.digest()) {
                actual.append(String.format(Locale.ROOT, "%02x", value & 0xff));
            }
            return actual.toString().equalsIgnoreCase(expected);
        } catch (Exception ignored) {
            return false;
        }
    }

    private static int compareVersions(String firstName, String secondName) {
        List<BigInteger> first = versionParts(firstName);
        List<BigInteger> second = versionParts(secondName);
        int max = Math.max(first.size(), second.size());
        for (int i = 0; i < max; i++) {
            BigInteger a = i < first.size() ? first.get(i) : BigInteger.ZERO;
            BigInteger b = i < second.size() ? second.get(i) : BigInteger.ZERO;
            int result = a.compareTo(b);
            if (result != 0) return result;
        }
        return firstName.compareToIgnoreCase(secondName);
    }

    private static List<BigInteger> versionParts(String fileName) {
        List<BigInteger> parts = new ArrayList<>();
        Matcher version = VERSION_PATTERN.matcher(fileName);
        if (!version.find()) return parts;
        Matcher number = Pattern.compile("[0-9]+").matcher(version.group(1));
        while (number.find()) parts.add(new BigInteger(number.group()));
        return parts;
    }

    private static String lastPathPart(String value) {
        if (value == null) return "";
        String clean = value;
        int query = clean.indexOf('?');
        if (query >= 0) clean = clean.substring(0, query);
        int hash = clean.indexOf('#');
        if (hash >= 0) clean = clean.substring(0, hash);
        int slash = clean.lastIndexOf('/');
        return slash >= 0 ? clean.substring(slash + 1) : clean;
    }

    private static String stripTags(String value) {
        return value.replaceAll("(?is)<[^>]*>", " ").replaceAll("\\s+", " ");
    }

    private static String decodeHtml(String value) {
        return value.replace("&amp;", "&")
                .replace("&quot;", "\"")
                .replace("&#39;", "'")
                .replace("&lt;", "<")
                .replace("&gt;", ">");
    }

    private static void log(LogCallback callback, String message) {
        if (callback != null) callback.onLog(message);
    }
}
