package com.samsung.twrp.flasher;

import android.os.Build;

/**
 * Read-only device information helper.
 *
 * Deliberately contains no su, dd, block-device writes, vbmeta patching,
 * recovery reboot, or partition-flashing commands.
 */
public final class SamsungFlashEngine {

    public static final class DeviceInfo {
        public final String manufacturer;
        public final String brand;
        public final String model;
        public final String device;
        public final String product;
        public final String androidVersion;
        public final int sdkInt;

        private DeviceInfo() {
            manufacturer = safe(Build.MANUFACTURER);
            brand = safe(Build.BRAND);
            model = safe(Build.MODEL);
            device = safe(Build.DEVICE);
            product = safe(Build.PRODUCT);
            androidVersion = safe(Build.VERSION.RELEASE);
            sdkInt = Build.VERSION.SDK_INT;
        }

        public String asText() {
            return "ÜRETİCİ : " + manufacturer
                    + "\nMARKA   : " + brand
                    + "\nMODEL   : " + model
                    + "\nDEVICE  : " + device
                    + "\nPRODUCT : " + product
                    + "\nANDROID : " + androidVersion
                    + " (API " + sdkInt + ")";
        }
    }

    private SamsungFlashEngine() { }

    public static DeviceInfo inspectDevice() {
        return new DeviceInfo();
    }

    /** Flashing is intentionally unavailable in this safety-focused build. */
    public static boolean isFlashingEnabled() {
        return false;
    }

    public static String flash(String imagePath) {
        return "İPTAL: Bu sürüm yalnızca indirme ve SHA-256 doğrulaması yapar. "
                + "Cihazın bölüm alanlarına yazma özelliği bulunmaz.";
    }

    private static String safe(String value) {
        return value == null || value.trim().isEmpty() ? "Bilinmiyor" : value.trim();
    }
}
