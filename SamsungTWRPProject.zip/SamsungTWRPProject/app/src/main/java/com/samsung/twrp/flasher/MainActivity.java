package com.samsung.twrp.flasher;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.Locale;

public class MainActivity extends Activity {

    private EditText deviceCodeInput;
    private Button downloadButton;
    private TextView deviceInfoText;
    private TextView statusBadge;
    private TextView logText;
    private ScrollView logScroll;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        deviceCodeInput = findViewById(R.id.deviceCodeInput);
        downloadButton = findViewById(R.id.downloadButton);
        deviceInfoText = findViewById(R.id.deviceInfoText);
        statusBadge = findViewById(R.id.statusBadge);
        logText = findViewById(R.id.logText);
        logScroll = findViewById(R.id.logScroll);
        progressBar = findViewById(R.id.progressBar);

        SamsungFlashEngine.DeviceInfo info = SamsungFlashEngine.inspectDevice();
        deviceInfoText.setText(info.asText());
        deviceCodeInput.setText(info.device.toLowerCase(Locale.ROOT));
        statusBadge.setText("FLASH KAPALI · İNDİRME MODU");
        appendLog("Uygulama hazır. Root izni istemez.");
        appendLog("Bu sürüm cihazın recovery veya vbmeta bölümlerine yazma yapmaz.");
        appendLog("Cihaz kod adını resmî TWRP destek sayfasıyla kendin doğrula.");

        downloadButton.setOnClickListener(v -> confirmAndDownload());
    }

    private void confirmAndDownload() {
        String code = deviceCodeInput.getText().toString().trim();
        if (!code.matches("[A-Za-z0-9_-]{1,64}")) {
            appendLog("HATA: Geçerli bir cihaz kod adı gir.");
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Cihaz kod adını doğrula")
                .setMessage("Girilen kod adı: " + code
                        + "\n\nBu kodun tam cihaz modeline ait olduğunu resmî TWRP cihaz sayfasından kontrol ettin mi?"
                        + "\n\nDevam edilirse yalnızca .img dosyası indirilir ve SHA-256 kontrolü yapılır. Telefona yazılmaz.")
                .setPositiveButton("İNDİR", (dialog, which) -> startDownload(code))
                .setNegativeButton("İPTAL", null)
                .show();
    }

    private void startDownload(String code) {
        setBusy(true);
        appendLog("\nCihaz dizini: " + code);

        Thread worker = new Thread(() -> {
            File cache = new File(getCacheDir(), "twrp_downloads");
            String result = SamsungTWRPFlasher.downloadLatestImg(code, cache, this::appendLog);

            runOnUiThread(() -> {
                if (result.startsWith("HATA:")) {
                    appendLog(result);
                } else {
                    appendLog("BAŞARILI: Dosya indirildi ve SHA-256 doğrulandı.");
                    appendLog("Yerel dosya: " + result);
                    appendLog("UYARI: Bu dosya otomatik olarak flashlanmayacaktır.");
                }
                setBusy(false);
            });
        }, "twrp-download-worker");
        worker.start();
    }

    private void setBusy(boolean busy) {
        downloadButton.setEnabled(!busy);
        deviceCodeInput.setEnabled(!busy);
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
    }

    private void appendLog(String message) {
        runOnUiThread(() -> {
            logText.append(message + "\n");
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        });
    }
}
